<!-- Create on the AWS Free account - Lambda Function which should calculate the Fubo sequence by receiving the user
   variable. In the Git repo create the Separate Folder in the Orion Sprint 1 named (AWS Projects) in this folder create the Readme.md 
   file with described:
   a. Lambda URL
   b. Payload to lambda
   c. Responce from Lambda
   d. Readme file should be done as document with Content, right described URL and full description
   e. check that lambda will not triger any paid resources -->